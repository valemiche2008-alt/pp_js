export default function taskCard(data){
    const statusColor = {
        initial: "bg-amber-400",
        process: "bg-emerald-200",
        completed: "bg-violet-200"
    }
    
    return`<div class="${statusColor[data.status]} p-3 rounded">
    <h3>Usuario ${data.user.full_name}</h3>
    <h1>${data.title}</h1>
    <p>${data.description}</p>
    <span>${data.status}</span>
    </div>
    `
}