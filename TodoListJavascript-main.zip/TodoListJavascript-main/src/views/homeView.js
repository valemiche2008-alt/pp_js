import { getTasks } from "../controllers/home.controller"

export default function homeView() {
    const user = JSON.parse(localStorage.getItem("user"))

    return `<h1>Hola <span id="name"></span></h1>

    <div class="grid grid-cols-4 gap-4" id="tasks-container">
    </div>
    `
}