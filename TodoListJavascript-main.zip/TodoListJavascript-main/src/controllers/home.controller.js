import taskCard from "../components/task"

export function homeController(tasks){
    const user = JSON.parse(localStorage.getItem("user"))
    
    const userInfo = document.getElementById("name")
    userInfo.innerText = user.full_name
    const container = document.getElementById("tasks-container")
    
    setTimeout(()=>{
        const cards = paintTasks(user, tasks)
        container.innerHTML = ""
        container.innerHTML += cards
    }, 1000)

    container.innerHTML = `<span class="col-span-4 text-center text-xl">
        Obteniendo data ...
    </span>`

    document.getElementById("logout").addEventListener("click", ()=>{
        localStorage.removeItem("user")
        window.location = "/login"
    })

}


export async function getTasks(){
    const user = JSON.parse(localStorage.getItem("user"))
    
    if(user.role ==="admin"){
        const response = await fetch("http://localhost:3000/todo_list?_embed=user")
        const data = await response.json()
        return data
    }else{
        const response = await fetch(`http://localhost:3000/todo_list?userId=${user.id}&_embed=user`)
        const data = await response.json()
        return data
    }
}

export function paintTasks(user, tasks) {
    
    if (!tasks.length) {
        return '<span class="col-span-4 text-center text-xl">No hay tareas para ver</span>'
    } else {
        if (user.role === "admin") {
            const cards = tasks.map(task => {
                return taskCard(task)
            }).join("")
            return cards
        } else {
            const tasksResult = tasks.filter(task =>  user.id === task.userId )
            const cards = tasksResult.map(task => {
                return taskCard(task)
            }).join("")
          return cards
        }
    }
}