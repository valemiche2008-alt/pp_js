import './style.css'
import { renderRoute } from './router'


document.addEventListener("DOMContentLoaded", renderRoute)

window.addEventListener("hashchange", renderRoute)

